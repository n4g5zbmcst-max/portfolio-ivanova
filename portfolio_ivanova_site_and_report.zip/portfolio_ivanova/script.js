// Плавная навигация и QR-код, который формируется из фактического адреса опубликованного сайта.
const qr = document.getElementById('site-qr');
if (qr && location.protocol !== 'file:') {
  qr.src = 'https://api.qrserver.com/v1/create-qr-code/?size=112x112&data=' + encodeURIComponent(location.href.split('#')[0]);
} else if (qr) {
  qr.alt = 'QR-код появится после публикации сайта на хостинге';
}
document.getElementById('contact-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const email = form.elements.email.value.trim();
  if (!email.includes('@')) {
    document.getElementById('form-note').textContent = 'Пожалуйста, укажите корректный Email с символом @.';
    form.elements.email.focus();
    return;
  }
  const subject = encodeURIComponent('Сообщение с сайта-портфолио');
  const body = encodeURIComponent(
    'Имя: ' + form.elements.name.value.trim() + '\n' +
    'Email отправителя: ' + email + '\n\n' +
    form.elements.message.value.trim()
  );
  document.getElementById('form-note').textContent = 'Открываем почтовое приложение. Проверьте текст письма и отправьте его.';
  window.location.href = 'mailto:ivatasya08@mail.ru?subject=' + subject + '&body=' + body;
});